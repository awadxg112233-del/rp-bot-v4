const { Client, GatewayIntentBits, Collection, REST, Routes, EmbedBuilder, ActivityType, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, ChannelType } = require('discord.js');
const fs = require('fs');
const path = require('path');
const colors = require('colors');
const config = require('./Config/config.loader');
const ticketHelper = require('./utils/ticketHelper');
const security = require('./utils/security');
const ButtonManager = require('./utils/buttons');
const PanelRefresher = require('./Refresher');
const lang = require('./utils/languageManager');
const db = require('./database/database');
const DatabaseConnector = require('./connector');

console.log(colors.cyan.bold('╔═══════════════════════════════════════╗'));
console.log(colors.cyan.bold('║         Ticket System v3.0          ║'));
console.log(colors.cyan.bold('║   Multi-Language + Database         ║'));
console.log(colors.cyan.bold('╚═══════════════════════════════════════╝'));

const defaultLang = config.get('settings.language') || 'ar';
lang.setLanguage(defaultLang);
console.log(colors.green(`✓ تم تعيين اللغة: ${defaultLang}`));

if (!config.validate()) {
    console.log(colors.red('\n❌ Please configure config.json first!'));
    process.exit(1);
}

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.DirectMessages
    ]
});

client.commands = new Collection();
const commandsPath = path.join(__dirname, 'Commands');

if (fs.existsSync(commandsPath)) {
    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
    
    for (const file of commandFiles) {
        const filePath = path.join(commandsPath, file);
        const command = require(filePath);
        if ('data' in command && 'execute' in command) {
            client.commands.set(command.data.name, command);
            console.log(colors.green(lang.getSystem('commandsLoaded', { command: command.data.name })));
        }
    }
}


const rest = new REST({ version: '10' }).setToken(config.get('token'));

(async () => {
    try {
        console.log(colors.yellow('\n⏳ Registering slash commands...'));

        const commands = Array.from(client.commands.values()).map(cmd => cmd.data.toJSON());
        
        await rest.put(
            Routes.applicationGuildCommands(config.get('clientId'), config.get('guildId')),
            { body: commands }
        );

        console.log(colors.green(lang.getSystem('commandsRegistered', { count: commands.length })));
    } catch (error) {
        console.error(colors.red('✗ Error registering commands:'), error);
    }
})();


const panelRefresher = new PanelRefresher(client);

const connector = new DatabaseConnector(client);


client.once('ready', () => {
    console.log(colors.green.bold(`\n✅ Logged in as ${client.user.tag}`));
    console.log(colors.cyan(`📊 Servers: ${client.guilds.cache.size}`));
    console.log(colors.cyan(`👥 Users: ${client.users.cache.size}`));
    
    client.user.setPresence({
        activities: [{ name: 'Ticket System | v3.0', type: ActivityType.Watching }],
        status: 'online'
    });


    client.guilds.cache.forEach(guild => {
        ticketHelper.syncCache(guild.id);
    });


    connector.initialize();

    client.connector = connector;


    setInterval(() => {
        security.cleanup();
    }, 3600000); // كل ساعة

    // تنظيف السجلات القديمة
    setInterval(() => {
        db.cleanupOldLogs(30); // حذف السجلات الأقدم من 30 يوم
    }, 86400000); // كل يوم


    const refreshMinutes = config.get('settings.autoRefreshMinutes') || 5;
    panelRefresher.startAutoRefresh(refreshMinutes);

    console.log(colors.green.bold('\n' + lang.getSystem('botReady') + '\n'));
});


client.on('messageCreate', async message => {
    if (message.author.bot) return;
    
    const ticket = ticketHelper.getTicket(message.channel.id);
    if (ticket) {
        await ticketHelper.saveMessage(message.channel.id, message);
    }
});


client.on('interactionCreate', async interaction => {
    if (interaction.isCommand()) {
        const command = client.commands.get(interaction.commandName);
        if (!command) return;

        try {
            await command.execute(interaction);
        } catch (error) {
            console.error(colors.red('Error executing command:'), error);
            const errorMsg = {
                content: lang.getMessage('error'),
                ephemeral: true
            };
            
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp(errorMsg);
            } else {
                await interaction.reply(errorMsg);
            }
        }
    }

    if (interaction.isButton()) {
        await handleButtonInteraction(interaction);
    }

    if (interaction.isStringSelectMenu()) {
        await handleSelectMenuInteraction(interaction);
    }

    if (interaction.isModalSubmit()) {
        await handleModalSubmit(interaction);
    }
});


async function handleButtonInteraction(interaction) {
    const securityCheck = await security.validateInteraction(interaction);
    if (!securityCheck.valid) {
        return await interaction.reply({
            content: securityCheck.reason,
            ephemeral: true
        });
    }

    const customId = interaction.customId;

    try {
        if (customId === 'open_ticket') {
            await handleOpenTicket(interaction);
        }
        else if (customId === 'claim_ticket') {
            await handleClaimTicket(interaction);
        }
        else if (customId === 'unclaim_ticket') {
            await handleUnclaimTicket(interaction);
        }
        else if (customId === 'close_ticket') {
            await handleCloseTicket(interaction);
        }
        else if (customId === 'transcript_ticket') {
            await handleTranscript(interaction);
        }
        else if (customId === 'confirm_close') {
            await handleConfirmClose(interaction);
        }
        else if (customId === 'cancel_close') {
            await interaction.update({ 
                content: lang.getMessage('closeCancelled'), 
                components: [], 
                embeds: [] 
            });
        }
        else if (customId === 'confirm_delete') {
            await handleConfirmDelete(interaction);
        }
        else if (customId === 'reopen_ticket') {
            await handleReopenTicket(interaction);
        }
        else if (customId.startsWith('panel_')) {
            await handlePanelButton(interaction);
        }
    } catch (error) {
        console.error(colors.red('Error handling button:'), error);
        const errorMsg = { content: lang.getMessage('error'), ephemeral: true };
        
        if (interaction.replied || interaction.deferred) {
            await interaction.followUp(errorMsg);
        } else {
            await interaction.reply(errorMsg);
        }
    }
}


async function handleOpenTicket(interaction) {
    await interaction.deferReply({ ephemeral: true });


    if (db.isBlacklisted(interaction.user.id, interaction.guild.id)) {
        return await interaction.editReply({
            content: lang.getSecurity('blacklisted')
        });
    }

    const result = await ticketHelper.createTicket(interaction.guild, interaction.user);

    if (!result.success) {
        return await interaction.editReply({
            content: result.message
        });
    }

    const channel = result.channel;
    
    const welcomeEmbed = new EmbedBuilder()
        .setTitle(lang.get('embeds.ticketCreated.title'))
        .setDescription(
            lang.get('embeds.ticketCreated.description', {
                user: interaction.user.toString()
            })
        )
        .setColor(config.getColor('success'))
        .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
        .setFooter({ 
            text: lang.get('embeds.ticketCreated.footer', { ticket: channel.name })
        })
        .setTimestamp();

    const controls = ButtonManager.createTicketControls(false);

    await channel.send({
        content: `${interaction.user} | <@&${config.get('roles.supportTeam')}>`,
        embeds: [welcomeEmbed],
        components: [controls]
    });

    await interaction.editReply({
        content: lang.getMessage('ticketCreatedSuccess', { channel: channel.toString() })
    });


    if (interaction.client.connector) {
        await interaction.client.connector.onTicketEvent('ticket_created', interaction.guild.id, {
            userId: interaction.user.id,
            ticketId: channel.id
        });
    }
}


async function handleClaimTicket(interaction) {
    if (!security.hasPermission(interaction.member, 'MANAGE_TICKETS')) {
        return await interaction.reply({
            content: lang.getMessage('noPermission'),
            ephemeral: true
        });
    }

    const result = await ticketHelper.claimTicket(interaction.channel, interaction.user);

    if (!result.success && result.alreadyClaimed) {
        return await interaction.reply({
            content: lang.getMessage('alreadyClaimed', { 
                staff: `<@${result.claimedBy}>` 
            }),
            ephemeral: true
        });
    }

    const embed = new EmbedBuilder()
        .setTitle(lang.get('embeds.ticketClaimed.title'))
        .setDescription(
            lang.get('embeds.ticketClaimed.description', {
                staff: interaction.user.toString()
            })
        )
        .setColor(config.getColor('success'))
        .setTimestamp();

    const newControls = ButtonManager.createTicketControls(true, interaction.user.id);

    await interaction.reply({ embeds: [embed] });
    

    const messages = await interaction.channel.messages.fetch({ limit: 10 });
    const originalMessage = messages.find(m => m.components.length > 0);
    if (originalMessage) {
        await originalMessage.edit({ components: [newControls] });
    }


    if (interaction.client.connector) {
        await interaction.client.connector.onTicketEvent('ticket_claimed', interaction.guild.id, {
            userId: interaction.user.id,
            ticketId: interaction.channel.id
        });
    }
}


async function handleUnclaimTicket(interaction) {
    const ticket = ticketHelper.getTicket(interaction.channel.id);
    
    if (!ticket || !ticket.claimed_by) {
        return await interaction.reply({
            content: lang.getMessage('notClaimed'),
            ephemeral: true
        });
    }


    if (ticket.claimed_by !== interaction.user.id && 
        !security.hasPermission(interaction.member, 'MANAGE_TICKETS')) {
        return await interaction.reply({
            content: lang.getMessage('onlyClaimerCanUnclaim', {
                staff: `<@${ticket.claimed_by}>`
            }),
            ephemeral: true
        });
    }

    await ticketHelper.unclaimTicket(interaction.channel);

    const embed = new EmbedBuilder()
        .setTitle(lang.get('embeds.ticketUnclaimed.title'))
        .setDescription(lang.get('embeds.ticketUnclaimed.description'))
        .setColor(config.getColor('warning'))
        .setTimestamp();

    const newControls = ButtonManager.createTicketControls(false);

    await interaction.reply({ embeds: [embed] });

    const messages = await interaction.channel.messages.fetch({ limit: 10 });
    const originalMessage = messages.find(m => m.components.length > 0);
    if (originalMessage) {
        await originalMessage.edit({ components: [newControls] });
    }

    if (interaction.client.connector) {
        await interaction.client.connector.onTicketEvent('ticket_unclaimed', interaction.guild.id, {
            userId: interaction.user.id,
            ticketId: interaction.channel.id
        });
    }
}


async function handleCloseTicket(interaction) {
    const ticket = ticketHelper.getTicket(interaction.channel.id);
    
    if (!ticket) {
        return await interaction.reply({
            content: lang.getMessage('ticketNotFound'),
            ephemeral: true
        });
    }
    if (ticket.user_id === interaction.user.id) {
        return await interaction.reply({
            content: lang.getMessage('cannotCloseOwnTicket'),
            ephemeral: true
        });
    }

    if (!security.hasPermission(interaction.member, 'MANAGE_TICKETS')) {
        return await interaction.reply({
            content: lang.getMessage('noPermission'),
            ephemeral: true
        });
    }

    if (ticket.status === 'closed') {
        return await interaction.reply({
            content: lang.getMessage('ticketAlreadyClosed'),
            ephemeral: true
        });
    }

    const confirmEmbed = new EmbedBuilder()
        .setTitle(lang.get('embeds.confirmClose.title'))
        .setDescription(lang.get('embeds.confirmClose.description'))
        .setColor(config.getColor('warning'))
        .setTimestamp();

    const confirmButtons = ButtonManager.createCloseConfirmation();

    await interaction.reply({
        embeds: [confirmEmbed],
        components: [confirmButtons],
        ephemeral: true
    });
}


async function handleConfirmClose(interaction) {
    await interaction.deferUpdate();
    
    await ticketHelper.closeTicket(interaction.channel, interaction.user);

    const closeEmbed = new EmbedBuilder()
        .setTitle(lang.get('embeds.ticketClosed.title'))
        .setDescription(
            lang.get('embeds.ticketClosed.description', {
                staff: interaction.user.toString()
            })
        )
        .setColor(config.getColor('error'))
        .setTimestamp();

    const deleteButtons = ButtonManager.createDeleteConfirmation();

    await interaction.channel.send({
        embeds: [closeEmbed],
        components: [deleteButtons]
    });

    await interaction.editReply({
        content: lang.getMessage('ticketClosedSuccess'),
        embeds: [],
        components: []
    });

    if (interaction.client.connector) {
        await interaction.client.connector.onTicketEvent('ticket_closed', interaction.guild.id, {
            userId: interaction.user.id,
            ticketId: interaction.channel.id
        });
    }
}

async function handleConfirmDelete(interaction) {
    await interaction.reply({
        content: lang.getMessage('ticketDeletedIn', { seconds: '5' })
    });

    const ticketId = interaction.channel.id;
    const guildId = interaction.guild.id;

    setTimeout(async () => {
        await ticketHelper.deleteTicket(interaction.channel);
        
     
        if (interaction.client.connector) {
            await interaction.client.connector.onTicketEvent('ticket_deleted', guildId, {
                ticketId: ticketId
            });
        }
    }, 5000);
}

async function handleReopenTicket(interaction) {
    if (!security.hasPermission(interaction.member, 'MANAGE_TICKETS')) {
        return await interaction.reply({
            content: lang.getMessage('noPermission'),
            ephemeral: true
        });
    }

    await ticketHelper.reopenTicket(interaction.channel, interaction.user);

    const reopenEmbed = new EmbedBuilder()
        .setTitle(lang.get('embeds.ticketReopened.title'))
        .setDescription(
            lang.get('embeds.ticketReopened.description', {
                staff: interaction.user.toString()
            })
        )
        .setColor(config.getColor('success'))
        .setTimestamp();

    const controls = ButtonManager.createTicketControls(false);

    await interaction.update({
        embeds: [reopenEmbed],
        components: [controls]
    });

    if (interaction.client.connector) {
        await interaction.client.connector.onTicketEvent('ticket_reopened', interaction.guild.id, {
            userId: interaction.user.id,
            ticketId: interaction.channel.id
        });
    }
}

async function handleTranscript(interaction) {
    await interaction.deferReply({ ephemeral: true });

    const transcript = await ticketHelper.generateTranscript(interaction.channel);

    if (!transcript) {
        return await interaction.editReply({
            content: lang.getMessage('error')
        });
    }

    const transcriptPath = path.join(__dirname, 'database', `transcript-${interaction.channel.id}.txt`);
    fs.writeFileSync(transcriptPath, transcript, 'utf8');

    const transcriptChannelId = config.get('channels.transcriptChannel');
    if (transcriptChannelId) {
        const transcriptChannel = await interaction.guild.channels.fetch(transcriptChannelId);
        if (transcriptChannel) {
            await transcriptChannel.send({
                content: `📝 Transcript for ${interaction.channel.name}`,
                files: [{ attachment: transcriptPath, name: `transcript-${interaction.channel.name}.txt` }]
            });
        }
    }

    await interaction.editReply({
        content: lang.getMessage('transcriptSaved'),
        files: [{ attachment: transcriptPath, name: `transcript-${interaction.channel.name}.txt` }]
    });

    setTimeout(() => {
        if (fs.existsSync(transcriptPath)) {
            fs.unlinkSync(transcriptPath);
        }
    }, 60000);
}

async function handlePanelButton(interaction) {
    const customId = interaction.customId;

    if (!security.hasPermission(interaction.member, 'MANAGE_TICKETS')) {
        return await interaction.reply({
            content: lang.getMessage('noPermission'),
            ephemeral: true
        });
    }

    if (customId === 'panel_refresh') {
        await interaction.deferReply({ ephemeral: true });
        await panelRefresher.refreshPanel(interaction.message, interaction);
    }
    else if (customId === 'panel_bot_status') {
        const menu = ButtonManager.createActivityMenu();
        await interaction.reply({
            content: lang.getSelectMenu('selectActivity'),
            components: [menu],
            ephemeral: true
        });
    }
    else if (customId === 'panel_bot_presence') {
        const menu = ButtonManager.createPresenceMenu();
        await interaction.reply({
            content: lang.getSelectMenu('selectPresence'),
            components: [menu],
            ephemeral: true
        });
    }
    else if (customId === 'panel_change_language') {
        const menu = ButtonManager.createLanguageMenu();
        await interaction.reply({
            content: lang.getSelectMenu('selectLanguage'),
            components: [menu],
            ephemeral: true
        });
    }
    else if (customId === 'panel_restart_bot') {
        await interaction.reply({
            content: lang.getMessage('restartingBot'),
            ephemeral: true
        });
        
        setTimeout(() => {
            process.exit(0);
        }, 2000);
    }
    else if (customId === 'panel_dm_all') {
        const modal = new ModalBuilder()
            .setCustomId('modal_dm_all')
            .setTitle(lang.getModal('dmAllTitle'));

        const messageInput = new TextInputBuilder()
            .setCustomId('dm_message')
            .setLabel(lang.getModal('dmAllLabel'))
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true)
            .setPlaceholder(lang.getModal('dmAllPlaceholder'));

        modal.addComponents(new ActionRowBuilder().addComponents(messageInput));
        await interaction.showModal(modal);
    }
    else if (customId === 'panel_message_all_tickets') {
        const modal = new ModalBuilder()
            .setCustomId('modal_message_tickets')
            .setTitle(lang.getModal('messageTicketsTitle'));

        const messageInput = new TextInputBuilder()
            .setCustomId('ticket_message')
            .setLabel(lang.getModal('messageTicketsLabel'))
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true)
            .setPlaceholder(lang.getModal('messageTicketsPlaceholder'));

        modal.addComponents(new ActionRowBuilder().addComponents(messageInput));
        await interaction.showModal(modal);
    }
    else if (customId === 'panel_navigate_ticket') {
        const tickets = ticketHelper.getAllTickets(interaction.guild.id);
        
        if (tickets.length === 0) {
            return await interaction.reply({
                content: lang.getMessage('noTicketsFound'),
                ephemeral: true
            });
        }

        const options = tickets.slice(0, 25).map(ticket => {
            const channel = interaction.guild.channels.cache.get(ticket.id);
            return {
                label: channel?.name || 'Deleted ticket',
                value: ticket.id,
                description: `Status: ${ticket.status}`,
                emoji: config.getEmoji('ticket')
            };
        });

        const { StringSelectMenuBuilder } = require('discord.js');
        const menu = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('navigate_ticket_select')
                .setPlaceholder(lang.getSelectMenu('selectTicket'))
                .addOptions(options)
        );

        await interaction.reply({
            content: lang.getSelectMenu('selectTicket'),
            components: [menu],
            ephemeral: true
        });
    }
}

async function handleSelectMenuInteraction(interaction) {
    const customId = interaction.customId;

    if (customId === 'select_activity') {
        const activity = interaction.values[0];
        const activityTypes = {
            'playing': ActivityType.Playing,
            'streaming': ActivityType.Streaming,
            'listening': ActivityType.Listening,
            'watching': ActivityType.Watching,
            'competing': ActivityType.Competing
        };

        client.user.setActivity('Ticket System v3.0', { type: activityTypes[activity] });
        
        await interaction.update({
            content: lang.getMessage('botActivityChanged', { activity }),
            components: []
        });
    }
    else if (customId === 'select_presence') {
        const presence = interaction.values[0];
        client.user.setStatus(presence);
        
        await interaction.update({
            content: lang.getMessage('botStatusChanged', { status: presence }),
            components: []
        });
    }
    else if (customId === 'select_language') {
        const newLang = interaction.values[0];
        lang.setLanguage(newLang);
        config.set('settings.language', newLang);
        
        await interaction.update({
            content: lang.getMessage('languageChanged'),
            components: []
        });
    }
    else if (customId === 'navigate_ticket_select') {
        const ticketId = interaction.values[0];
        const channel = interaction.guild.channels.cache.get(ticketId);
        
        if (!channel) {
            return await interaction.update({
                content: lang.getMessage('ticketNotFound'),
                components: []
            });
        }

        await interaction.update({
            content: `✅ ${channel.toString()}`,
            components: []
        });
    }
}


async function handleModalSubmit(interaction) {
    const customId = interaction.customId;

    if (customId === 'modal_dm_all') {
        await interaction.deferReply({ ephemeral: true });
        
        const message = interaction.fields.getTextInputValue('dm_message');
        const tickets = ticketHelper.getAllTickets(interaction.guild.id);
        let sent = 0;

        const uniqueUsers = new Set(tickets.map(t => t.user_id));

        for (const userId of uniqueUsers) {
            try {
                const user = await client.users.fetch(userId);
                await user.send(message);
                sent++;
            } catch (error) {
                console.error(`Failed to send to ${userId}:`, error);
            }
        }

        await interaction.editReply({
            content: lang.getMessage('dmSentSuccess', { count: sent })
        });
    }
    else if (customId === 'modal_message_tickets') {
        await interaction.deferReply({ ephemeral: true });
        
        const message = interaction.fields.getTextInputValue('ticket_message');
        const tickets = ticketHelper.getAllTickets(interaction.guild.id);
        let sent = 0;

        for (const ticket of tickets) {
            try {
                const channel = interaction.guild.channels.cache.get(ticket.id);
                if (channel && ticket.status !== 'closed') {
                    await channel.send(`<@${ticket.user_id}> ${message}`);
                    sent++;
                }
            } catch (error) {
                console.error(`Failed to send to ticket ${ticket.id}:`, error);
            }
        }

        await interaction.editReply({
            content: lang.getMessage('ticketMessagesSentSuccess', { count: sent })
        });
    }
}

process.on('unhandledRejection', error => {
    console.error(colors.red('Unhandled promise rejection:'), error);
});

process.on('uncaughtException', error => {
    console.error(colors.red('Uncaught exception:'), error);
});

process.on('SIGINT', async () => {
    console.log(colors.yellow('\n⏳ Shutting down...'));
    
    if (client.connector) {
        client.connector.cleanup();
    }
    
    const backupPath = path.join(__dirname, 'database', `backup-${Date.now()}.db`);
    await db.backup(backupPath);
    console.log(colors.green(`✓ Backup saved: ${backupPath}`));
    
    db.close();
    process.exit(0);
});

client.login(config.get('token')).catch(error => {
    console.error(colors.red('✗ فشل تسجيل الدخول:'), error);
    process.exit(1);
});