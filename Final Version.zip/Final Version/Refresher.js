const { EmbedBuilder } = require('discord.js');
const config = require('./Config/config.loader');
const ticketHelper = require('./utils/ticketHelper');

class PanelRefresher {
    constructor(client) {
        this.client = client;
        this.panels = new Map(); // messageId -> channelId
    }

    registerPanel(messageId, channelId) {
        this.panels.set(messageId, channelId);
    }

    unregisterPanel(messageId) {
        this.panels.delete(messageId);
    }

    async refreshPanel(message, interaction = null) {
        try {
            if (!message || !message.guild) return;

            const guild = message.guild;

            const openTickets = ticketHelper.getOpenTickets();
            const claimedTickets = ticketHelper.getClaimedTickets();
            const closedTickets = ticketHelper.getClosedTickets();
            
            const supportRole = await guild.roles.fetch(config.get('roles.supportTeam'));
            const adminRole = await guild.roles.fetch(config.get('roles.adminTeam'));
            
            const staffCount = new Set([
                ...supportRole.members.keys(),
                ...adminRole.members.keys()
            ]).size;

            const panelEmbed = new EmbedBuilder()
                .setTitle(config.getMessage('ticketPanelTitle'))
                .setDescription(
                    '**مرحباً بك في لوحة التحكم الإدارية**\n\n' +
                    'من هنا يمكنك إدارة جميع جوانب نظام التذاكر والبوت'
                )
                .setColor(config.getColor('primary'))
                .addFields(
                    {
                        name: `${config.getEmoji('ticket')} ${config.getMessage('openTickets')}`,
                        value: `\`\`\`${openTickets.length}\`\`\``,
                        inline: true
                    },
                    {
                        name: `${config.getEmoji('claim')} ${config.getMessage('claimedTickets')}`,
                        value: `\`\`\`${claimedTickets.length}\`\`\``,
                        inline: true
                    },
                    {
                        name: `${config.getEmoji('close')} ${config.getMessage('closedTickets')}`,
                        value: `\`\`\`${closedTickets.length}\`\`\``,
                        inline: true
                    },
                    {
                        name: `${config.getEmoji('bot')} ${config.getMessage('staffMembers')}`,
                        value: `\`\`\`${staffCount}\`\`\``,
                        inline: true
                    },
                    {
                        name: `${config.getEmoji('online')} حالة البوت`,
                        value: `\`\`\`${this.client.user.presence.status}\`\`\``,
                        inline: true
                    },
                    {
                        name: `⚡ نشاط البوت`,
                        value: `\`\`\`${this.client.user.presence.activities[0]?.name || 'لا يوجد'}\`\`\``,
                        inline: true
                    }
                )
                .setThumbnail(this.client.user.displayAvatarURL({ dynamic: true }))
                .setFooter({
                    text: `${guild.name} | آخر تحديث`,
                    iconURL: guild.iconURL()
                })
                .setTimestamp();

            await message.edit({
                embeds: [panelEmbed],
                components: message.components
            });

            if (interaction) {
                await interaction.followUp({
                    content: '✅ تم تحديث اللوحة بنجاح',
                    ephemeral: true
                });
            }

            return true;
        } catch (error) {
            console.error('خطأ في تحديث اللوحة:', error);
            return false;
        }
    }

    async refreshAllPanels() {
        for (const [messageId, channelId] of this.panels) {
            try {
                const channel = await this.client.channels.fetch(channelId);
                if (!channel) continue;

                const message = await channel.messages.fetch(messageId);
                if (!message) continue;

                await this.refreshPanel(message);
            } catch (error) {
                console.error(`خطأ في تحديث اللوحة ${messageId}:`, error);
            }
        }
    }

    startAutoRefresh(intervalMinutes = 5) {
        setInterval(() => {
            this.refreshAllPanels();
        }, intervalMinutes * 60 * 1000);

        console.log(`✅ تم تفعيل التحديث التلقائي كل ${intervalMinutes} دقائق`);
    }
}

module.exports = PanelRefresher;