const { EmbedBuilder } = require('discord.js');
const colors = require('colors');
const config = require('./Config/config.loader');
const db = require('./database/database');

class DatabaseConnector {
    constructor(client) {
        this.client = client;
        this.updateInterval = null;
        this.panels = new Map(); // messageId -> { channelId, guildId }
        this.stats = {
            openTickets: 0,
            claimedTickets: 0,
            closedTickets: 0,
            totalTickets: 0
        };
    }

    initialize() {
        console.log(colors.cyan('🔌 جاري تهيئة نظام التحديث التلقائي...'));
        
        this.syncFromDatabase();
        
        this.startAutoUpdate();
        
        console.log(colors.green('✅ تم تهيئة نظام التحديث التلقائي بنجاح'));
    }

    syncFromDatabase() {
        try {
            this.client.guilds.cache.forEach(guild => {
                const guildStats = db.getGuildStats(guild.id);
                
                console.log(colors.yellow(`📊 إحصائيات ${guild.name}:`));
                console.log(colors.white(`   - المفتوحة: ${guildStats.open}`));
                console.log(colors.white(`   - المستلمة: ${guildStats.claimed}`));
                console.log(colors.white(`   - المغلقة: ${guildStats.closed}`));
                console.log(colors.white(`   - الإجمالي: ${guildStats.total}`));
            });
        } catch (error) {
            console.error(colors.red('❌ خطأ في مزامنة البيانات:'), error);
        }
    }

    registerPanel(messageId, channelId, guildId) {
        this.panels.set(messageId, { channelId, guildId });
        console.log(colors.green(`✓ تم تسجيل لوحة التحكم: ${messageId}`));
    }

    unregisterPanel(messageId) {
        this.panels.delete(messageId);
        console.log(colors.yellow(`- تم إلغاء تسجيل لوحة التحكم: ${messageId}`));
    }

    startAutoUpdate(intervalSeconds = 5) {
        if (this.updateInterval) {
            clearInterval(this.updateInterval);
        }

        this.updateInterval = setInterval(() => {
            this.updateAllPanels();
        }, intervalSeconds * 1000);

        console.log(colors.green(`✅ تم تفعيل التحديث التلقائي كل ${intervalSeconds} ثانية`));
    }

    stopAutoUpdate() {
        if (this.updateInterval) {
            clearInterval(this.updateInterval);
            this.updateInterval = null;
            console.log(colors.yellow('⏸️ تم إيقاف التحديث التلقائي'));
        }
    }

    async updateAllPanels() {
        for (const [messageId, data] of this.panels) {
            try {
                await this.updatePanel(messageId, data.channelId, data.guildId);
            } catch (error) {
                console.error(colors.red(`❌ خطأ في تحديث اللوحة ${messageId}:`), error.message);
                if (error.code === 10008 || error.code === 10003) {
                    this.unregisterPanel(messageId);
                }
            }
        }
    }

    async updatePanel(messageId, channelId, guildId) {
        try {
            const channel = await this.client.channels.fetch(channelId);
            if (!channel) {
                this.unregisterPanel(messageId);
                return;
            }

            const message = await channel.messages.fetch(messageId);
            if (!message) {
                this.unregisterPanel(messageId);
                return;
            }

            const guild = this.client.guilds.cache.get(guildId);
            if (!guild) return;

            const stats = db.getGuildStats(guildId);
            
            const supportRole = await guild.roles.fetch(config.get('roles.supportTeam')).catch(() => null);
            const adminRole = await guild.roles.fetch(config.get('roles.adminTeam')).catch(() => null);
            
            const staffCount = new Set([
                ...(supportRole?.members.keys() || []),
                ...(adminRole?.members.keys() || [])
            ]).size;

            const panelEmbed = new EmbedBuilder()
                .setTitle('🎫 لوحة التحكم - نظام التذاكر')
                .setDescription(
                    '**مرحباً بك في لوحة التحكم الإدارية**\n\n' +
                    'من هنا يمكنك إدارة جميع جوانب نظام التذاكر والبوت\n\n' +
                    '🔄 **آخر تحديث:** <t:' + Math.floor(Date.now() / 1000) + ':R>'
                )
                .setColor(config.getColor('primary'))
                .addFields(
                    {
                        name: `${config.getEmoji('ticket')} التذاكر المفتوحة`,
                        value: `\`\`\`${stats.open}\`\`\``,
                        inline: true
                    },
                    {
                        name: `${config.getEmoji('claim')} التذاكر المستلمة`,
                        value: `\`\`\`${stats.claimed}\`\`\``,
                        inline: true
                    },
                    {
                        name: `${config.getEmoji('close')} التذاكر المغلقة`,
                        value: `\`\`\`${stats.closed}\`\`\``,
                        inline: true
                    },
                    {
                        name: `📊 إجمالي التذاكر`,
                        value: `\`\`\`${stats.total}\`\`\``,
                        inline: true
                    },
                    {
                        name: `${config.getEmoji('bot')} عدد الإداريين`,
                        value: `\`\`\`${staffCount}\`\`\``,
                        inline: true
                    },
                    {
                        name: `${config.getEmoji('online')} حالة البوت`,
                        value: `\`\`\`${this.client.user.presence.status}\`\`\``,
                        inline: true
                    }
                )
                .setThumbnail(this.client.user.displayAvatarURL({ dynamic: true }))
                .setFooter({
                    text: `${guild.name} | تحديث تلقائي كل 5 ثواني`,
                    iconURL: guild.iconURL()
                })
                .setTimestamp();

            await message.edit({
                embeds: [panelEmbed],
                components: message.components
            });

        } catch (error) {
            if (error.code !== 10008 && error.code !== 10003) {
                console.error(colors.red('خطأ في تحديث اللوحة:'), error.message);
            }
            throw error;
        }
    }

    async instantUpdate(guildId) {
        const panelsToUpdate = [];
        
        for (const [messageId, data] of this.panels) {
            if (data.guildId === guildId) {
                panelsToUpdate.push({ messageId, ...data });
            }
        }

        for (const panel of panelsToUpdate) {
            try {
                await this.updatePanel(panel.messageId, panel.channelId, panel.guildId);
            } catch (error) {
                console.error(colors.red(`خطأ في التحديث الفوري للوحة ${panel.messageId}:`), error.message);
            }
        }
    }

    getStats(guildId) {
        return db.getGuildStats(guildId);
    }

    async onTicketEvent(eventType, guildId, data = {}) {
        console.log(colors.cyan(`📋 حدث: ${eventType} في ${guildId}`));
        
        await this.instantUpdate(guildId);

        const logMessages = {
            'ticket_created': `تم إنشاء تذكرة جديدة`,
            'ticket_claimed': `تم استلام تذكرة`,
            'ticket_unclaimed': `تم إلغاء استلام تذكرة`,
            'ticket_closed': `تم إغلاق تذكرة`,
            'ticket_deleted': `تم حذف تذكرة`,
            'ticket_reopened': `تم إعادة فتح تذكرة`
        };

        db.addLog(
            guildId,
            eventType,
            data.userId || null,
            data.ticketId || null,
            logMessages[eventType] || eventType
        );
    }

    getPanels() {
        return Array.from(this.panels.entries()).map(([messageId, data]) => ({
            messageId,
            ...data
        }));
    }

    cleanup() {
        this.stopAutoUpdate();
        this.panels.clear();
        console.log(colors.yellow('🧹 تم تنظيف نظام التحديث التلقائي'));
    }

    getSystemStats() {
        return {
            registeredPanels: this.panels.size,
            updateInterval: this.updateInterval ? 'نشط' : 'متوقف',
            client: {
                guilds: this.client.guilds.cache.size,
                users: this.client.users.cache.size,
                uptime: this.client.uptime
            }
        };
    }

    displayStats() {
        console.log(colors.cyan('\n╔════════════════════════════════════╗'));
        console.log(colors.cyan('║     إحصائيات نظام التحديث        ║'));
        console.log(colors.cyan('╚════════════════════════════════════╝'));
        
        const systemStats = this.getSystemStats();
        
        console.log(colors.white(`📊 اللوحات المسجلة: ${systemStats.registeredPanels}`));
        console.log(colors.white(`🔄 حالة التحديث: ${systemStats.updateInterval}`));
        console.log(colors.white(`🌐 السيرفرات: ${systemStats.client.guilds}`));
        console.log(colors.white(`👥 المستخدمين: ${systemStats.client.users}`));
        
        if (systemStats.client.uptime) {
            const uptime = Math.floor(systemStats.client.uptime / 1000);
            const hours = Math.floor(uptime / 3600);
            const minutes = Math.floor((uptime % 3600) / 60);
            const seconds = uptime % 60;
            console.log(colors.white(`⏱️ وقت التشغيل: ${hours}س ${minutes}د ${seconds}ث`));
        }
        
        console.log(colors.cyan('════════════════════════════════════\n'));
    }
}

module.exports = DatabaseConnector;