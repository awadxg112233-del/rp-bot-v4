const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const config = require('../Config/config.loader');
const ButtonManager = require('../utils/buttons');
const security = require('../utils/security');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup_ticket')
        .setDescription('Send ticket creation message')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addChannelOption(option =>
            option
                .setName('channel')
                .setDescription('Channel to send the message in')
                .setRequired(false)
        )
        .addStringOption(option =>
            option
                .setName('title')
                .setDescription('Message title')
                .setRequired(false)
        )
        .addStringOption(option =>
            option
                .setName('description')
                .setDescription('Message description')
                .setRequired(false)
        ),

    async execute(interaction) {
        try {
            if (!security.hasPermission(interaction.member, 'MANAGE_TICKETS')) {
                return await interaction.reply({
                    content: config.getMessage('noPermission'),
                    ephemeral: true
                });
            }

            await interaction.deferReply({ ephemeral: true });

            const channel = interaction.options.getChannel('channel') || interaction.channel;
            const title = interaction.options.getString('title') || '🎫 نظام التذاكر';
            const description = interaction.options.getString('description') || 
                'مرحباً بك في نظام التذاكر!\n\n' +
                '📋 للحصول على المساعدة، اضغط على الزر أدناه لفتح تذكرة جديدة\n' +
                '✅ سيتم الرد عليك في أقرب وقت ممكن من قبل فريق الدعم\n' +
                '⚡ يرجى التحلي بالصبر وعدم فتح تذاكر متعددة\n\n' +
                '**ملاحظة:** يمكنك فتح حتى 3 تذاكر في نفس الوقت';

            const embed = new EmbedBuilder()
                .setTitle(title)
                .setDescription(description)
                .setColor(config.getColor('primary'))
                .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
                .setFooter({ 
                    text: `${interaction.guild.name} | نظام التذاكر`,
                    iconURL: interaction.guild.iconURL()
                })
                .setTimestamp();

            const button = ButtonManager.createTicketButton();

            await channel.send({
                embeds: [embed],
                components: [button]
            });

            const successEmbed = new EmbedBuilder()
                .setTitle('✅ تم بنجاح')
                .setDescription(`تم إرسال رسالة التذاكر في ${channel}`)
                .setColor(config.getColor('success'))
                .setTimestamp();

            await interaction.editReply({
                embeds: [successEmbed]
            });

        } catch (error) {
            console.error('خطأ في أمر setup_ticket:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setTitle('❌ خطأ')
                .setDescription('حدث خطأ أثناء إرسال رسالة التذاكر')
                .setColor(config.getColor('error'))
                .setTimestamp();

            if (interaction.deferred) {
                await interaction.editReply({ embeds: [errorEmbed] });
            } else {
                await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }
        }
    }
};