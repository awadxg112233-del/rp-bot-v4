const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const config = require('../Config/config.loader');
const ButtonManager = require('../utils/buttons');
const security = require('../utils/security');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup_panel')
        .setDescription('Send control panel')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addChannelOption(option =>
            option
                .setName('channel')
                .setDescription('Channel to send the panel in')
                .setRequired(false)
        ),

    async execute(interaction) {
        try {
    
            if (!security.hasPermission(interaction.member, 'MANAGE_TICKETS')) {
                return await interaction.reply({
                    content: 'ليس لديك صلاحية لتنفيذ هذا الأمر',
                    ephemeral: true
                });
            }

            await interaction.deferReply({ ephemeral: true });

            const channel = interaction.options.getChannel('channel') || interaction.channel;

       
            const db = require('../database/database');
            const stats = db.getGuildStats(interaction.guild.id);
            
            const supportRole = await interaction.guild.roles.fetch(config.get('roles.supportTeam')).catch(() => null);
            const adminRole = await interaction.guild.roles.fetch(config.get('roles.adminTeam')).catch(() => null);
            
            const staffCount = new Set([
                ...(supportRole?.members.keys() || []),
                ...(adminRole?.members.keys() || [])
            ]).size;


            const panelEmbed = new EmbedBuilder()
                .setTitle('🎫 لوحة التحكم - نظام التذاكر')
                .setDescription(
                    '**مرحباً بك في لوحة التحكم الإدارية**\n\n' +
                    'من هنا يمكنك إدارة جميع جوانب نظام التذاكر والبوت\n\n' +
                    '🔄 **يتم التحديث تلقائياً كل 5 ثواني**'
                )
                .setColor(config.getColor('primary'))
                .addFields(
                    {
                        name: `${config.getEmoji('ticket')} التذاكر المفتوحة`,
                        value: `\`\`\`${stats.open}\`\`\``,
                        inline: true
                    },
                    {
                        name: `${config.getEmoji('claim')} التذاكر المستلمة`,
                        value: `\`\`\`${stats.claimed}\`\`\``,
                        inline: true
                    },
                    {
                        name: `${config.getEmoji('close')} التذاكر المغلقة`,
                        value: `\`\`\`${stats.closed}\`\`\``,
                        inline: true
                    },
                    {
                        name: `📊 إجمالي التذاكر`,
                        value: `\`\`\`${stats.total}\`\`\``,
                        inline: true
                    },
                    {
                        name: `${config.getEmoji('bot')} عدد الإداريين`,
                        value: `\`\`\`${staffCount}\`\`\``,
                        inline: true
                    },
                    {
                        name: `${config.getEmoji('online')} حالة البوت`,
                        value: `\`\`\`${interaction.client.user.presence.status}\`\`\``,
                        inline: true
                    }
                )
                .setThumbnail(interaction.client.user.displayAvatarURL({ dynamic: true }))
                .setFooter({
                    text: `${interaction.guild.name} | تحديث تلقائي كل 5 ثواني`,
                    iconURL: interaction.guild.iconURL()
                })
                .setTimestamp();


            const buttons = ButtonManager.createPanelButtons();

            const sentMessage = await channel.send({
                embeds: [panelEmbed],
                components: buttons
            });
  
     
            if (interaction.client.connector) {
                interaction.client.connector.registerPanel(
                    sentMessage.id, 
                    channel.id, 
                    interaction.guild.id
                );
                console.log('✅ تم تسجيل لوحة التحكم للتحديث التلقائي');
            }

            const successEmbed = new EmbedBuilder()
                .setTitle('✅ تم بنجاح')
                .setDescription(
                    `تم إرسال لوحة التحكم في ${channel}\n\n` +
                    `🔄 اللوحة ستتحدث تلقائياً كل 5 ثواني`
                )
                .setColor(config.getColor('success'))
                .setTimestamp();

            await interaction.editReply({
                embeds: [successEmbed]
            });

        } catch (error) {
            console.error('خطأ في أمر setup_panel:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setTitle('❌ خطأ')
                .setDescription('حدث خطأ أثناء إرسال لوحة التحكم')
                .setColor(config.getColor('error'))
                .setTimestamp();

            if (interaction.deferred) {
                await interaction.editReply({ embeds: [errorEmbed] });
            } else {
                await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }
        }
    }
};