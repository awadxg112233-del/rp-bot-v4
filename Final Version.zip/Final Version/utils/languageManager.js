const fs = require('fs');
const path = require('path');
const colors = require('colors');

class LanguageManager {
    constructor() {
        this.languages = new Map();
        this.currentLanguage = 'ar';
        this.langPath = path.join(__dirname, '../lang');
        this.loadLanguages();
    }

    loadLanguages() {
        try {
            const files = fs.readdirSync(this.langPath).filter(file => file.endsWith('.json'));
            
            for (const file of files) {
                const langCode = file.replace('.json', '');
                const langData = JSON.parse(
                    fs.readFileSync(path.join(this.langPath, file), 'utf8')
                );
                this.languages.set(langCode, langData);
                console.log(colors.green(`✓ تم تحميل اللغة: ${langCode}`));
            }

            if (this.languages.size === 0) {
                throw new Error('لم يتم العثور على ملفات لغة');
            }
        } catch (error) {
            console.error(colors.red('✗ فشل تحميل ملفات اللغة:'), error.message);
            process.exit(1);
        }
    }

    setLanguage(langCode) {
        if (!this.languages.has(langCode)) {
            console.warn(colors.yellow(`⚠ اللغة ${langCode} غير متوفرة، استخدام اللغة الافتراضية`));
            return false;
        }
        this.currentLanguage = langCode;
        return true;
    }

    getLanguage() {
        return this.currentLanguage;
    }

    get(key, replacements = {}) {
        const lang = this.languages.get(this.currentLanguage);
        if (!lang) {
            return key;
        }


        const value = key.split('.').reduce((obj, k) => obj?.[k], lang);
        
        if (!value) {
            console.warn(colors.yellow(`⚠ المفتاح "${key}" غير موجود في اللغة ${this.currentLanguage}`));
            return key;
        }


        if (typeof value === 'string' && Object.keys(replacements).length > 0) {
            return this.replaceVariables(value, replacements);
        }

        return value;
    }

    replaceVariables(text, replacements) {
        let result = text;
        for (const [key, value] of Object.entries(replacements)) {
            result = result.replace(new RegExp(`{${key}}`, 'g'), value);
        }
        return result;
    }


    getEmbed(embedKey, replacements = {}) {
        return this.get(`embeds.${embedKey}`, replacements);
    }

    getButton(buttonKey) {
        return this.get(`buttons.${buttonKey}`);
    }

    getMessage(messageKey, replacements = {}) {
        return this.get(`messages.${messageKey}`, replacements);
    }

    getField(fieldKey) {
        return this.get(`fields.${fieldKey}`);
    }

    getLog(logKey, replacements = {}) {
        return this.get(`logs.${logKey}`, replacements);
    }

    getSelectMenu(menuKey) {
        return this.get(`selectMenus.${menuKey}`);
    }

    getModal(modalKey) {
        return this.get(`modals.${modalKey}`);
    }

    getCommand(commandKey) {
        return this.get(`commands.${commandKey}`);
    }

    getSecurity(securityKey, replacements = {}) {
        return this.get(`security.${securityKey}`, replacements);
    }

    getSystem(systemKey, replacements = {}) {
        return this.get(`system.${systemKey}`, replacements);
    }

    getTranscript(transcriptKey, replacements = {}) {
        return this.get(`transcript.${transcriptKey}`, replacements);
    }


    getObject(key) {
        const lang = this.languages.get(this.currentLanguage);
        return key.split('.').reduce((obj, k) => obj?.[k], lang);
    }

    getAvailableLanguages() {
        return Array.from(this.languages.keys());
    }


    hasLanguage(langCode) {
        return this.languages.has(langCode);
    }


    reload() {
        this.languages.clear();
        this.loadLanguages();
        console.log(colors.green('✓ تم إعادة تحميل جميع ملفات اللغة'));
    }


    getCurrentLanguageInfo() {
        return {
            code: this.currentLanguage,
            data: this.languages.get(this.currentLanguage)
        };
    }
}

module.exports = new LanguageManager();