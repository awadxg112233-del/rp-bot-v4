const config = require('../Config/config.loader');

class SecurityManager {
    constructor() {
        this.rateLimits = new Map(); // userId -> { count, resetTime }
        this.blacklist = new Set();
        this.suspiciousActivities = new Map();
    }


    hasPermission(member, permission) {
        if (!member) return false;
        
        const adminRole = config.get('roles.adminTeam');
        const supportRole = config.get('roles.supportTeam');


        if (member.roles.cache.has(adminRole) || member.permissions.has('Administrator')) {
            return true;
        }


        if (permission === 'MANAGE_TICKETS' && member.roles.cache.has(supportRole)) {
            return true;
        }

        return false;
    }

    // فحص Rate Limiting
    checkRateLimit(userId, action, limit = 5, windowMs = 60000) {
        const now = Date.now();
        const key = `${userId}-${action}`;
        
        if (!this.rateLimits.has(key)) {
            this.rateLimits.set(key, {
                count: 1,
                resetTime: now + windowMs
            });
            return true;
        }

        const data = this.rateLimits.get(key);
        
        if (now > data.resetTime) {

            this.rateLimits.set(key, {
                count: 1,
                resetTime: now + windowMs
            });
            return true;
        }

        if (data.count >= limit) {
            this.logSuspiciousActivity(userId, action, 'rate_limit_exceeded');
            return false;
        }

        data.count++;
        return true;
    }


    logSuspiciousActivity(userId, action, reason) {
        if (!this.suspiciousActivities.has(userId)) {
            this.suspiciousActivities.set(userId, []);
        }

        this.suspiciousActivities.get(userId).push({
            action,
            reason,
            timestamp: Date.now()
        });

    
        if (this.suspiciousActivities.get(userId).length > 10) {
            this.blacklist.add(userId);
            console.warn(`⚠️ تم حظر المستخدم ${userId} بسبب نشاطات مشبوهة`);
        }
    }


    isBlacklisted(userId) {
        return this.blacklist.has(userId);
    }


    removeFromBlacklist(userId) {
        this.blacklist.delete(userId);
        this.suspiciousActivities.delete(userId);
    }

 
    cleanup() {
        const now = Date.now();
        const maxAge = 3600000; // ساعة واحدة

        // تنظيف rate limits
        for (const [key, data] of this.rateLimits.entries()) {
            if (now > data.resetTime) {
                this.rateLimits.delete(key);
            }
        }


        for (const [userId, activities] of this.suspiciousActivities.entries()) {
            const filtered = activities.filter(a => now - a.timestamp < maxAge);
            if (filtered.length === 0) {
                this.suspiciousActivities.delete(userId);
            } else {
                this.suspiciousActivities.set(userId, filtered);
            }
        }
    }


    async validateInteraction(interaction) {
        const userId = interaction.user.id;

        if (this.isBlacklisted(userId)) {
            return {
                valid: false,
                reason: 'تم حظرك من استخدام هذا البوت'
            };
        }

        // فحص Rate Limit
        if (!this.checkRateLimit(userId, interaction.customId || interaction.commandName)) {
            return {
                valid: false,
                reason: 'أنت تقوم بإجراءات كثيرة جداً، يرجى الانتظار قليلاً'
            };
        }

        return { valid: true };
    }

   
    sanitizeContent(content) {

        return content
            .replace(/@everyone/g, '@ everyone')
            .replace(/@here/g, '@ here')
            .trim()
            .substring(0, 2000); // حد Discord
    }

    canManageChannel(member, channel) {
        if (!member || !channel) return false;
        
        return member.permissions.has('ManageChannels') ||
               this.hasPermission(member, 'MANAGE_TICKETS');
    }
}

module.exports = new SecurityManager();