const { PermissionFlagsBits, ChannelType } = require('discord.js');
const config = require('../Config/config.loader');
const db = require('../database/database');
const lang = require('./languageManager');

class TicketHelper {
    constructor() {
        this.activeTickets = new Map(); // للكاش السريع
    }

    async createTicket(guild, user, category = 'general') {
        try {
            const guildSettings = db.getSettings(guild.id);
            
            const userTickets = db.getUserTickets(user.id, guild.id, 'open');
            const claimedTickets = db.getUserTickets(user.id, guild.id, 'claimed');
            const totalOpen = userTickets.length + claimedTickets.length;
            
            const maxTickets = guildSettings.max_tickets_per_user || 3;

            if (totalOpen >= maxTickets) {
                return { 
                    success: false, 
                    message: lang.getMessage('maxTicketsReached', { max: maxTickets })
                };
            }

            const categoryId = config.get('channels.ticketCategory');
            const supportRoleId = config.get('roles.supportTeam');
            
            const ticketNumber = db.getNextTicketNumber(guild.id);
            const ticketName = guildSettings.ticket_name_format
                .replace('{username}', user.username)
                .replace('{number}', ticketNumber)
                .replace('{id}', user.id.slice(-4));

            const channel = await guild.channels.create({
                name: ticketName,
                type: ChannelType.GuildText,
                parent: categoryId,
                permissionOverwrites: [
                    {
                        id: guild.id,
                        deny: [PermissionFlagsBits.ViewChannel]
                    },
                    {
                        id: user.id,
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ReadMessageHistory,
                            PermissionFlagsBits.AttachFiles,
                            PermissionFlagsBits.EmbedLinks
                        ]
                    },
                    {
                        id: supportRoleId,
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ReadMessageHistory,
                            PermissionFlagsBits.ManageMessages,
                            PermissionFlagsBits.AttachFiles,
                            PermissionFlagsBits.EmbedLinks
                        ]
                    }
                ]
            });

            
            db.createTicket({
                id: channel.id,
                user_id: user.id,
                guild_id: guild.id,
                channel_id: channel.id,
                category: category
            });

           
            db.updateUserStats(user.id, guild.id, { total: 1 });

     
            db.addLog(
                guild.id,
                'ticket_created',
                user.id,
                channel.id,
                lang.getLog('ticketCreated', { user: user.tag })
            );


            this.activeTickets.set(channel.id, {
                id: channel.id,
                userId: user.id,
                status: 'open'
            });

            return {
                success: true,
                channel: channel,
                ticketNumber: ticketNumber
            };

        } catch (error) {
            console.error('خطأ في إنشاء التذكرة:', error);
            return {
                success: false,
                message: lang.getMessage('error')
            };
        }
    }

    async closeTicket(channel, closedBy) {
        const ticket = db.getTicket(channel.id);
        if (!ticket) return false;

        if (ticket.status === 'closed') return false;

   
        db.updateTicketStatus(channel.id, 'closed', closedBy.id);

  
        db.updateUserStats(ticket.user_id, ticket.guild_id, { closed: 1 });

     
        db.updateStaffStats(closedBy.id, ticket.guild_id, { closed: 1 });


        db.addLog(
            ticket.guild_id,
            'ticket_closed',
            closedBy.id,
            channel.id,
            lang.getLog('ticketClosed', { ticket: channel.name, staff: closedBy.tag })
        );

  
        await channel.permissionOverwrites.edit(ticket.user_id, {
            SendMessages: false,
            ViewChannel: true
        });

        // تحديث الكاش
        if (this.activeTickets.has(channel.id)) {
            this.activeTickets.get(channel.id).status = 'closed';
        }

        return true;
    }

    async deleteTicket(channel) {
        const ticket = db.getTicket(channel.id);
        if (!ticket) return false;

       
        db.deleteTicket(channel.id);


        db.addLog(
            ticket.guild_id,
            'ticket_deleted',
            null,
            channel.id,
            lang.getLog('ticketDeleted', { ticket: channel.name })
        );


        this.activeTickets.delete(channel.id);


        await channel.delete();
        return true;
    }

    async claimTicket(channel, user) {
        const ticket = db.getTicket(channel.id);
        if (!ticket) return false;

        if (ticket.claimed_by) {
            return { success: false, alreadyClaimed: true, claimedBy: ticket.claimed_by };
        }

     
        db.updateTicketStatus(channel.id, 'claimed', user.id);

        db.updateStaffStats(user.id, ticket.guild_id, { claimed: 1 });


        db.addLog(
            ticket.guild_id,
            'ticket_claimed',
            user.id,
            channel.id,
            lang.getLog('ticketClaimed', { ticket: channel.name, staff: user.tag })
        );


        if (this.activeTickets.has(channel.id)) {
            this.activeTickets.get(channel.id).status = 'claimed';
            this.activeTickets.get(channel.id).claimedBy = user.id;
        }

        return { success: true };
    }

    async unclaimTicket(channel) {
        const ticket = db.getTicket(channel.id);
        if (!ticket) return false;

        if (!ticket.claimed_by) {
            return { success: false, notClaimed: true };
        }


        db.updateTicketStatus(channel.id, 'open');

     
        db.addLog(
            ticket.guild_id,
            'ticket_unclaimed',
            null,
            channel.id,
            lang.getLog('ticketUnclaimed', { ticket: channel.name })
        );

      
        if (this.activeTickets.has(channel.id)) {
            this.activeTickets.get(channel.id).status = 'open';
            this.activeTickets.get(channel.id).claimedBy = null;
        }

        return { success: true };
    }

    async reopenTicket(channel, user) {
        const ticket = db.getTicket(channel.id);
        if (!ticket) return false;

        if (ticket.status !== 'closed') return false;

      
        db.updateTicketStatus(channel.id, 'open');

   
        db.addLog(
            ticket.guild_id,
            'ticket_reopened',
            user.id,
            channel.id,
            lang.getLog('ticketReopened', { ticket: channel.name, staff: user.tag })
        );

   
        await channel.permissionOverwrites.edit(ticket.user_id, {
            SendMessages: true,
            ViewChannel: true
        });

      
        if (this.activeTickets.has(channel.id)) {
            this.activeTickets.get(channel.id).status = 'open';
        } else {
            this.activeTickets.set(channel.id, {
                id: channel.id,
                userId: ticket.user_id,
                status: 'open'
            });
        }

        return true;
    }

    getTicket(channelId) {
        return db.getTicket(channelId);
    }

    getUserTicketCount(userId, guildId) {
        const openTickets = db.getUserTickets(userId, guildId, 'open');
        const claimedTickets = db.getUserTickets(userId, guildId, 'claimed');
        return openTickets.length + claimedTickets.length;
    }

    getOpenTickets(guildId) {
        return db.getTicketsByStatus(guildId, 'open');
    }

    getClaimedTickets(guildId) {
        return db.getTicketsByStatus(guildId, 'claimed');
    }

    getClosedTickets(guildId) {
        return db.getTicketsByStatus(guildId, 'closed');
    }

    getAllTickets(guildId) {
        return db.getAllTickets(guildId);
    }

    async saveMessage(ticketId, message) {
        const attachments = message.attachments.map(att => ({
            name: att.name,
            url: att.url,
            size: att.size
        }));

        db.addMessage({
            id: message.id,
            ticket_id: ticketId,
            user_id: message.author.id,
            content: message.content,
            timestamp: message.createdTimestamp,
            attachments: attachments
        });
    }

    async generateTranscript(channel) {
        const ticket = db.getTicket(channel.id);
        if (!ticket) return null;

        const messages = db.getTicketMessages(channel.id);
        
        let transcript = lang.getTranscript('header', { ticket: channel.name }) + '\n';
        transcript += lang.getTranscript('createdAt', { 
            date: new Date(ticket.created_at).toLocaleString(lang.getLanguage() === 'ar' ? 'ar-SA' : 'en-US')
        }) + '\n';
        transcript += lang.getTranscript('owner', { user: `<@${ticket.user_id}>` }) + '\n';
        
        if (ticket.claimed_by) {
            transcript += lang.getTranscript('claimedBy', { staff: `<@${ticket.claimed_by}>` }) + '\n';
        }
        
        if (ticket.closed_by) {
            transcript += lang.getTranscript('closedBy', { staff: `<@${ticket.closed_by}>` }) + '\n';
        }
        
        transcript += '\n' + lang.getTranscript('messagesHeader') + '\n\n';

        messages.forEach(msg => {
            const timestamp = new Date(msg.timestamp).toLocaleString(lang.getLanguage() === 'ar' ? 'ar-SA' : 'en-US');
            transcript += `[${timestamp}] <@${msg.user_id}>: ${msg.content || '(محتوى مرفق)'}\n`;
            
            if (msg.attachments && msg.attachments.length > 0) {
                msg.attachments.forEach(att => {
                    transcript += `  📎 ${att.name} - ${att.url}\n`;
                });
            }
        });

        db.addLog(
            ticket.guild_id,
            'transcript_created',
            null,
            channel.id,
            lang.getLog('transcriptCreated', { ticket: channel.name })
        );

        return transcript;
    }

    getGuildStats(guildId) {
        return db.getGuildStats(guildId);
    }

    getUserStats(userId) {
        return db.getUserStats(userId);
    }

    getStaffStats(userId) {
        return db.getStaffStats(userId);
    }


    clearCache() {
        this.activeTickets.clear();
    }

  
    syncCache(guildId) {
        this.clearCache();
        const tickets = this.getAllTickets(guildId);
        tickets.forEach(ticket => {
            if (ticket.status !== 'closed') {
                this.activeTickets.set(ticket.id, {
                    id: ticket.id,
                    userId: ticket.user_id,
                    status: ticket.status,
                    claimedBy: ticket.claimed_by
                });
            }
        });
    }
}

module.exports = new TicketHelper();