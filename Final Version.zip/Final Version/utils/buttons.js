const { ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');
const config = require('../Config/config.loader');

class ButtonManager {
    static createTicketButton() {
        return new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('open_ticket')
                .setLabel('فتح تذكرة')
                .setEmoji(config.getEmoji('ticket'))
                .setStyle(ButtonStyle.Primary)
        );
    }

    static createTicketControls(isClaimed = false, claimedBy = null) {
        const row = new ActionRowBuilder();

        if (!isClaimed) {
            row.addComponents(
                new ButtonBuilder()
                    .setCustomId('claim_ticket')
                    .setLabel('استلام')
                    .setEmoji(config.getEmoji('claim'))
                    .setStyle(ButtonStyle.Success)
            );
        } else {
            row.addComponents(
                new ButtonBuilder()
                    .setCustomId('unclaim_ticket')
                    .setLabel('إلغاء الاستلام')
                    .setEmoji(config.getEmoji('unclaim'))
                    .setStyle(ButtonStyle.Secondary)
            );
        }

        row.addComponents(
            new ButtonBuilder()
                .setCustomId('close_ticket')
                .setLabel('إغلاق')
                .setEmoji(config.getEmoji('close'))
                .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
                .setCustomId('transcript_ticket')
                .setLabel('نسخة')
                .setEmoji(config.getEmoji('transcript'))
                .setStyle(ButtonStyle.Secondary)
        );

        return row;
    }

    static createCloseConfirmation() {
        return new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('confirm_close')
                .setLabel('تأكيد الإغلاق')
                .setEmoji('✅')
                .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
                .setCustomId('cancel_close')
                .setLabel('إلغاء')
                .setEmoji('❌')
                .setStyle(ButtonStyle.Secondary)
        );
    }

    static createDeleteConfirmation() {
        return new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('confirm_delete')
                .setLabel('حذف نهائي')
                .setEmoji(config.getEmoji('delete'))
                .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
                .setCustomId('reopen_ticket')
                .setLabel('إعادة فتح')
                .setEmoji(config.getEmoji('reopen'))
                .setStyle(ButtonStyle.Success)
        );
    }

    static createPanelButtons() {
        const row1 = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('panel_bot_status')
                .setLabel('تغيير حالة البوت')
                .setEmoji(config.getEmoji('bot'))
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('panel_bot_presence')
                .setLabel('تغيير اتصال البوت')
                .setEmoji(config.getEmoji('online'))
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('panel_navigate_ticket')
                .setLabel('انتقال إلى تذكرة')
                .setEmoji(config.getEmoji('ticket'))
                .setStyle(ButtonStyle.Secondary)
        );

        const row2 = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('panel_restart_bot')
                .setLabel('إعادة تشغيل البوت')
                .setEmoji(config.getEmoji('restart'))
                .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
                .setCustomId('panel_dm_all')
                .setLabel('رسالة خاصة للجميع')
                .setEmoji(config.getEmoji('message'))
                .setStyle(ButtonStyle.Secondary)
        );

        const row3 = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('panel_message_all_tickets')
                .setLabel('رسالة لكل التذاكر')
                .setEmoji(config.getEmoji('message'))
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId('panel_change_language')
                .setLabel('تغيير اللغة')
                .setEmoji(config.getEmoji('language'))
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('panel_refresh')
                .setLabel('تحديث')
                .setEmoji('🔄')
                .setStyle(ButtonStyle.Success)
        );

        return [row1, row2, row3];
    }

    static createActivityMenu() {
        return new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('select_activity')
                .setPlaceholder('اختر نوع النشاط')
                .addOptions([
                    {
                        label: 'Playing',
                        description: 'يلعب',
                        value: 'playing',
                        emoji: '🎮'
                    },
                    {
                        label: 'Streaming',
                        description: 'يبث',
                        value: 'streaming',
                        emoji: '📺'
                    },
                    {
                        label: 'Listening',
                        description: 'يستمع',
                        value: 'listening',
                        emoji: '🎵'
                    },
                    {
                        label: 'Watching',
                        description: 'يشاهد',
                        value: 'watching',
                        emoji: '👀'
                    },
                    {
                        label: 'Competing',
                        description: 'يتنافس',
                        value: 'competing',
                        emoji: '🏆'
                    }
                ])
        );
    }

    static createPresenceMenu() {
        return new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('select_presence')
                .setPlaceholder('اختر حالة الاتصال')
                .addOptions([
                    {
                        label: 'Online',
                        description: 'متصل',
                        value: 'online',
                        emoji: '🟢'
                    },
                    {
                        label: 'Idle',
                        description: 'في وضع الخمول',
                        value: 'idle',
                        emoji: '🟡'
                    },
                    {
                        label: 'Do Not Disturb',
                        description: 'عدم الإزعاج',
                        value: 'dnd',
                        emoji: '🔴'
                    },
                    {
                        label: 'Invisible',
                        description: 'غير مرئي',
                        value: 'invisible',
                        emoji: '⚫'
                    }
                ])
        );
    }

    static createLanguageMenu() {
        return new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('select_language')
                .setPlaceholder('اختر اللغة')
                .addOptions([
                    {
                        label: 'العربية',
                        description: 'Arabic Language',
                        value: 'ar',
                        emoji: '🇸🇦'
                    },
                    {
                        label: 'English',
                        description: 'English Language',
                        value: 'en',
                        emoji: '🇺🇸'
                    }
                ])
        );
    }
}

module.exports = ButtonManager;