const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
const colors = require('colors');

class DatabaseManager {
    constructor() {
        const dbDir = path.join(__dirname, '../database');
        

        if (!fs.existsSync(dbDir)) {
            fs.mkdirSync(dbDir, { recursive: true });
        }

        this.dbPath = path.join(dbDir, 'tickets.db');
        this.db = new Database(this.dbPath);
        this.db.pragma('journal_mode = WAL'); // أداء أفضل
        this.initialize();
    }

    initialize() {
        try {
            // جدول التذاكر
            this.db.exec(`
                CREATE TABLE IF NOT EXISTS tickets (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    guild_id TEXT NOT NULL,
                    channel_id TEXT NOT NULL,
                    status TEXT DEFAULT 'open',
                    claimed_by TEXT,
                    closed_by TEXT,
                    created_at INTEGER NOT NULL,
                    claimed_at INTEGER,
                    closed_at INTEGER,
                    ticket_number INTEGER,
                    category TEXT DEFAULT 'general'
                )
            `);

            this.db.exec(`
                CREATE TABLE IF NOT EXISTS messages (
                    id TEXT PRIMARY KEY,
                    ticket_id TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    content TEXT,
                    timestamp INTEGER NOT NULL,
                    attachments TEXT,
                    FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE
                )
            `);


            this.db.exec(`
                CREATE TABLE IF NOT EXISTS user_stats (
                    user_id TEXT PRIMARY KEY,
                    guild_id TEXT NOT NULL,
                    total_tickets INTEGER DEFAULT 0,
                    closed_tickets INTEGER DEFAULT 0,
                    average_response_time INTEGER DEFAULT 0,
                    last_ticket_at INTEGER
                )
            `);


            this.db.exec(`
                CREATE TABLE IF NOT EXISTS staff_stats (
                    user_id TEXT PRIMARY KEY,
                    guild_id TEXT NOT NULL,
                    tickets_claimed INTEGER DEFAULT 0,
                    tickets_closed INTEGER DEFAULT 0,
                    average_close_time INTEGER DEFAULT 0,
                    rating REAL DEFAULT 0.0
                )
            `);


            this.db.exec(`
                CREATE TABLE IF NOT EXISTS logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    guild_id TEXT NOT NULL,
                    action TEXT NOT NULL,
                    user_id TEXT,
                    ticket_id TEXT,
                    details TEXT,
                    timestamp INTEGER NOT NULL
                )
            `);

            this.db.exec(`
                CREATE TABLE IF NOT EXISTS settings (
                    guild_id TEXT PRIMARY KEY,
                    language TEXT DEFAULT 'ar',
                    max_tickets_per_user INTEGER DEFAULT 3,
                    ticket_name_format TEXT DEFAULT 'ticket-{username}',
                    auto_close_hours INTEGER DEFAULT 48,
                    welcome_message TEXT,
                    support_role_id TEXT,
                    admin_role_id TEXT,
                    category_id TEXT,
                    logs_channel_id TEXT,
                    transcript_channel_id TEXT
                )
            `);

    
            this.db.exec(`
                CREATE TABLE IF NOT EXISTS blacklist (
                    user_id TEXT PRIMARY KEY,
                    guild_id TEXT NOT NULL,
                    reason TEXT,
                    added_by TEXT,
                    added_at INTEGER NOT NULL
                )
            `);

    
            this.db.exec(`
                CREATE INDEX IF NOT EXISTS idx_tickets_user ON tickets(user_id);
                CREATE INDEX IF NOT EXISTS idx_tickets_status ON tickets(status);
                CREATE INDEX IF NOT EXISTS idx_tickets_guild ON tickets(guild_id);
                CREATE INDEX IF NOT EXISTS idx_messages_ticket ON messages(ticket_id);
                CREATE INDEX IF NOT EXISTS idx_logs_guild ON logs(guild_id);
            `);

            console.log(colors.green('✓ تم تهيئة قاعدة البيانات بنجاح'));
        } catch (error) {
            console.error(colors.red('✗ فشل تهيئة قاعدة البيانات:'), error.message);
            throw error;
        }
    }

    // ========== إدارة التذاكر ==========

    createTicket(ticketData) {
        const stmt = this.db.prepare(`
            INSERT INTO tickets (id, user_id, guild_id, channel_id, status, created_at, ticket_number, category)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `);

        const ticketNumber = this.getNextTicketNumber(ticketData.guild_id);
        
        return stmt.run(
            ticketData.id,
            ticketData.user_id,
            ticketData.guild_id,
            ticketData.channel_id,
            'open',
            Date.now(),
            ticketNumber,
            ticketData.category || 'general'
        );
    }

    getTicket(ticketId) {
        const stmt = this.db.prepare('SELECT * FROM tickets WHERE id = ? OR channel_id = ?');
        return stmt.get(ticketId, ticketId);
    }

    updateTicketStatus(ticketId, status, userId = null) {
        const updates = { status };
        const timestamp = Date.now();

        if (status === 'claimed' && userId) {
            updates.claimed_by = userId;
            updates.claimed_at = timestamp;
        } else if (status === 'closed' && userId) {
            updates.closed_by = userId;
            updates.closed_at = timestamp;
        } else if (status === 'open') {
            updates.claimed_by = null;
            updates.claimed_at = null;
        }

        const setClause = Object.keys(updates).map(key => `${key} = ?`).join(', ');
        const stmt = this.db.prepare(`UPDATE tickets SET ${setClause} WHERE id = ?`);
        
        return stmt.run(...Object.values(updates), ticketId);
    }

    deleteTicket(ticketId) {
        const stmt = this.db.prepare('DELETE FROM tickets WHERE id = ?');
        return stmt.run(ticketId);
    }

    getUserTickets(userId, guildId, status = null) {
        let query = 'SELECT * FROM tickets WHERE user_id = ? AND guild_id = ?';
        const params = [userId, guildId];

        if (status) {
            query += ' AND status = ?';
            params.push(status);
        }

        const stmt = this.db.prepare(query);
        return stmt.all(...params);
    }

    getTicketsByStatus(guildId, status) {
        const stmt = this.db.prepare('SELECT * FROM tickets WHERE guild_id = ? AND status = ?');
        return stmt.all(guildId, status);
    }

    getAllTickets(guildId) {
        const stmt = this.db.prepare('SELECT * FROM tickets WHERE guild_id = ?');
        return stmt.all(guildId);
    }

    getNextTicketNumber(guildId) {
        const stmt = this.db.prepare('SELECT MAX(ticket_number) as max FROM tickets WHERE guild_id = ?');
        const result = stmt.get(guildId);
        return (result.max || 0) + 1;
    }

    // ========== إدارة الرسائل ==========

    addMessage(messageData) {
        const stmt = this.db.prepare(`
            INSERT INTO messages (id, ticket_id, user_id, content, timestamp, attachments)
            VALUES (?, ?, ?, ?, ?, ?)
        `);

        return stmt.run(
            messageData.id,
            messageData.ticket_id,
            messageData.user_id,
            messageData.content,
            messageData.timestamp || Date.now(),
            JSON.stringify(messageData.attachments || [])
        );
    }

    getTicketMessages(ticketId) {
        const stmt = this.db.prepare('SELECT * FROM messages WHERE ticket_id = ? ORDER BY timestamp ASC');
        const messages = stmt.all(ticketId);
        
        return messages.map(msg => ({
            ...msg,
            attachments: JSON.parse(msg.attachments || '[]')
        }));
    }

    // ========== الإحصائيات ==========

    updateUserStats(userId, guildId, increment = {}) {
        const stmt = this.db.prepare(`
            INSERT INTO user_stats (user_id, guild_id, total_tickets, closed_tickets, last_ticket_at)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                total_tickets = total_tickets + ?,
                closed_tickets = closed_tickets + ?,
                last_ticket_at = ?
        `);

        const now = Date.now();
        return stmt.run(
            userId, guildId,
            increment.total || 0,
            increment.closed || 0,
            now,
            increment.total || 0,
            increment.closed || 0,
            now
        );
    }

    updateStaffStats(userId, guildId, increment = {}) {
        const stmt = this.db.prepare(`
            INSERT INTO staff_stats (user_id, guild_id, tickets_claimed, tickets_closed)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                tickets_claimed = tickets_claimed + ?,
                tickets_closed = tickets_closed + ?
        `);

        return stmt.run(
            userId, guildId,
            increment.claimed || 0,
            increment.closed || 0,
            increment.claimed || 0,
            increment.closed || 0
        );
    }

    getUserStats(userId) {
        const stmt = this.db.prepare('SELECT * FROM user_stats WHERE user_id = ?');
        return stmt.get(userId);
    }

    getStaffStats(userId) {
        const stmt = this.db.prepare('SELECT * FROM staff_stats WHERE user_id = ?');
        return stmt.get(userId);
    }

    getGuildStats(guildId) {
        const tickets = this.getAllTickets(guildId);
        return {
            total: tickets.length,
            open: tickets.filter(t => t.status === 'open').length,
            claimed: tickets.filter(t => t.status === 'claimed').length,
            closed: tickets.filter(t => t.status === 'closed').length
        };
    }

    // ========== السجلات ==========

    addLog(guildId, action, userId, ticketId, details) {
        const stmt = this.db.prepare(`
            INSERT INTO logs (guild_id, action, user_id, ticket_id, details, timestamp)
            VALUES (?, ?, ?, ?, ?, ?)
        `);

        return stmt.run(guildId, action, userId, ticketId, details, Date.now());
    }

    getLogs(guildId, limit = 100) {
        const stmt = this.db.prepare(`
            SELECT * FROM logs WHERE guild_id = ? ORDER BY timestamp DESC LIMIT ?
        `);
        return stmt.all(guildId, limit);
    }

    // ========== الإعدادات ==========

    getSettings(guildId) {
        const stmt = this.db.prepare('SELECT * FROM settings WHERE guild_id = ?');
        let settings = stmt.get(guildId);

        if (!settings) {

            this.db.prepare(`
                INSERT INTO settings (guild_id) VALUES (?)
            `).run(guildId);
            settings = stmt.get(guildId);
        }

        return settings;
    }

    updateSettings(guildId, updates) {
        const keys = Object.keys(updates);
        const setClause = keys.map(key => `${key} = ?`).join(', ');
        const stmt = this.db.prepare(`
            UPDATE settings SET ${setClause} WHERE guild_id = ?
        `);

        return stmt.run(...Object.values(updates), guildId);
    }

    // ========== القائمة السوداء ==========

    addToBlacklist(userId, guildId, reason, addedBy) {
        const stmt = this.db.prepare(`
            INSERT OR REPLACE INTO blacklist (user_id, guild_id, reason, added_by, added_at)
            VALUES (?, ?, ?, ?, ?)
        `);

        return stmt.run(userId, guildId, reason, addedBy, Date.now());
    }

    removeFromBlacklist(userId) {
        const stmt = this.db.prepare('DELETE FROM blacklist WHERE user_id = ?');
        return stmt.run(userId);
    }

    isBlacklisted(userId, guildId) {
        const stmt = this.db.prepare('SELECT * FROM blacklist WHERE user_id = ? AND guild_id = ?');
        return stmt.get(userId, guildId) !== undefined;
    }

    // ========== التنظيف ==========

    cleanupOldLogs(daysOld = 30) {
        const cutoff = Date.now() - (daysOld * 24 * 60 * 60 * 1000);
        const stmt = this.db.prepare('DELETE FROM logs WHERE timestamp < ?');
        return stmt.run(cutoff);
    }

    // ========== النسخ الاحتياطي ==========

    backup(backupPath) {
        const backup = this.db.backup(backupPath);
        return new Promise((resolve, reject) => {
            backup.step(-1, (err) => {
                if (err) reject(err);
                else {
                    backup.close();
                    resolve();
                }
            });
        });
    }

    // إغلاق الاتصال
    close() {
        this.db.close();
    }
}

module.exports = new DatabaseManager();