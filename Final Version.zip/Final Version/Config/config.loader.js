const fs = require('fs');
const path = require('path');
const colors = require('colors');

class ConfigLoader {
    constructor() {
        this.configPath = path.join(__dirname, 'config.json');
        this.config = null;
        this.load();
    }

    load() {
        try {
            const data = fs.readFileSync(this.configPath, 'utf8');
            this.config = JSON.parse(data);
            console.log(colors.green('✓ تم تحميل ملف التكوين بنجاح'));
            return this.config;
        } catch (error) {
            console.error(colors.red('✗ فشل تحميل ملف التكوين:'), error.message);
            process.exit(1);
        }
    }

    save() {
        try {
            fs.writeFileSync(this.configPath, JSON.stringify(this.config, null, 2));
            console.log(colors.green('✓ تم حفظ التكوين بنجاح'));
            return true;
        } catch (error) {
            console.error(colors.red('✗ فشل حفظ التكوين:'), error.message);
            return false;
        }
    }

    get(key) {
        return key.split('.').reduce((obj, k) => obj?.[k], this.config);
    }

    set(key, value) {
        const keys = key.split('.');
        const lastKey = keys.pop();
        const target = keys.reduce((obj, k) => obj[k] = obj[k] || {}, this.config);
        target[lastKey] = value;
        this.save();
    }

    getMessage(key) {
        const lang = this.get('settings.language') || 'ar';
        return this.get(`messages.${lang}.${key}`) || key;
    }

    getEmoji(key) {
        return this.get(`emojis.${key}`) || '';
    }

    getColor(key) {
        return this.get(`colors.${key}`) || '#2F3136';
    }

    validate() {
        const required = ['token', 'clientId', 'guildId'];
        const missing = required.filter(key => !this.get(key) || this.get(key).includes('HERE'));
        
        if (missing.length > 0) {
            console.log(colors.yellow('⚠ تحذير: الحقول التالية تحتاج إلى تكوين:'));
            missing.forEach(key => console.log(colors.yellow(`  - ${key}`)));
            return false;
        }
        return true;
    }

    reload() {
        return this.load();
    }
}

module.exports = new ConfigLoader();